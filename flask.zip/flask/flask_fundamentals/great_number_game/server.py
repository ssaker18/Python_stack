from flask import Flask, session, redirect, render_template, request
import random
app= Flask(__name__)
app.secret_key= 'secret'


@app.route('/')
def index(x=5):
    if 'num' in session:
        print('key exists!')
    else:
        print("key 'num' does NOT exist, creating one!")
        session['num']=random.randint(1, 100)
    return render_template('index.html', x=x)

@app.route('/<val>')
def value(val):
    return render_template('index.html', x= int(val))



@app.route('/answer', methods=['POST'])
def guess():
    session['guess'] = int(request.form["number"])
    if session['guess']>session['num']:
        path='/2'
        return redirect(path)
    elif session['guess']<session['num']:
        path='/0'
        return redirect(path)
    elif session['guess']==session['num']:
        path='/1'
        return redirect(path)

@app.route('/destroy_session', methods=['POST'])
def destroy():
    session.clear()
    return redirect('/')





  
if __name__ == "__main__":
    app.run(debug=True)
