from flask import Flask, render_template
app = Flask(__name__)

@app.route('/play')
def level1():
    return render_template('index.html')

@app.route('/play/<times>')
def level2(times):
    times = int(times)
    return render_template('index.html', x=times)

@app.route('/play/<times>/<color>')
def level3(times, color):
    times = int(times)
    return render_template('index.html', x=times, color=color)


if __name__=="__main__":
    app.run(debug=True)                   
