from flask import Flask, session, redirect, render_template, request
from mysqlconnection import connectToMySQL
app=Flask(__name__)
app.secret_key='secret'

@app.route('/users')
def index():
    mysql = connectToMySQL("mydb")
    friends = mysql.query_db("SELECT * FROM friends;")
    return render_template('index2.html', all_friends=friends)

@app.route('/users/new')
def new():
    return render_template("index.html")


@app.route('/users/create', methods=['POST'])
def process():
    mysql=connectToMySQL("mydb")
    query= "INSERT INTO friends (first_name, last_name, email, created_at, updated_at) VALUES (%(fn)s, %(ln)s, %(em)s, NOW(), NOW());"
    data ={
        'fn':request.form['fname'],
        'ln':request.form['lname'],
        'em':request.form['email']
    }
    friend_id = str(mysql.query_db(query, data))
    string= '/users/'+friend_id
    return redirect(string)


@app.route('/users/<friend_id>')
def show_one(friend_id):
    real_id=""
    for character in friend_id:
        if character.isnumeric() == True:
            real_id+=character
    query = "SELECT * FROM friends WHERE id = %(f_id)s"
    data={
        'f_id':real_id
    }
    mysql = connectToMySQL("mydb")
    dictionary = mysql.query_db(query, data)
    

    return render_template("index3.html", user=dictionary[0])



@app.route('/users/<friend_id>/update', methods=['POST'])
def edit_user(friend_id):
    real_id=""
    for character in friend_id:
        if character.isnumeric() == True:
            real_id+=character
    mysql=connectToMySQL("mydb")
    query= "UPDATE friends SET first_name = %(fn)s, last_name= %(ln)s, email = %(em)s, updated_at = NOW() WHERE id = %(id)s;"
    data ={
        'fn':request.form['fname'],
        'ln':request.form['lname'],
        'em':request.form['email'],
        'id':real_id
    }
    str='/users/'+friend_id #redirect only knows to pass a string; the '<>' do not work outside of app.route 
    mysql.query_db(query, data)
    return redirect(str)

@app.route('/users/<friend_id>/edit')
def edit_user_temp(friend_id):
    real_id=""
    for character in friend_id:
        if character.isnumeric() == True:
            real_id+=character
    return render_template("index4.html", friend_id=real_id)



@app.route("/users/<friend_id>/destroy")
def destroy(friend_id):
    query = "DELETE FROM friends WHERE id = %(id)s"
    
    mysql = connectToMySQL("mydb")
    mysql.query_db(query, {"id": friend_id})

    return redirect("/users")

 