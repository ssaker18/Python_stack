from flask import Flask, render_template, request, redirect, flash

app = Flask(__name__)
@app.route('/')
def index():
    mysql = connectToMySQL("mydb")
    friends = mysql.query_db("SELECT * FROM friends;") 
    print(friends)
    return render_template("index.html", all_friends = friends)
  
@app.route('/create_friend', methods=['POST'])
def process():
    is_valid = True
    if len(request.form['fname']) < 1:
    	is_valid = False
    	flash("Please enter a first name")
    if len(request.form['lname']) < 1:
    	is_valid = False
    	flash("Please enter a last name")
    if len(request.form['occ']) < 2:
    	is_valid = False
    	flash("Occupation should be at least 2 characters")
    
    if not is_valid:
        return redirect("/")
    else:
    	# add user to database
        flash("Friend successfully added!")
        return redirect("/")    # eventually we may have a different success route
if __name__=="__main__":
    app.run(debug=True)