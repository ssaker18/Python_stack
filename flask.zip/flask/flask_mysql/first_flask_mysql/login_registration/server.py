from flask import Flask, session, redirect, render_template, request, flash
from mysqlconnection import connectToMySQL
import re	# the regex module
from flask_bcrypt import Bcrypt   
app=Flask(__name__)
app.secret_key='secret'

bcrypt = Bcrypt(app)     

USER_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')




@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    is_valid=True
    mysql = connectToMySQL('mydb')
    query = ("SELECT * FROM users WHERE emails= %(em)s")
    data={
        'fn':request.form['fname'],
        'ln':request.form['lname'],
        'em':request.form['email'],
        'pw':bcrypt.generate_password_hash(request.form['password'])
    }
    email_list= mysql.query_db(query, data)

    if request.form['password']!=request.form['confirm']:
        flash("Passwords must match!")
        is_valid=False
    if len('fn')<2 or not 'fn'.isalpha():
        flash("First name must be at least two characters and can only contain alphabeticals!")
        is_valid=False
    if len('ln')<2 or not 'ln'.isalpha():
        flash("Last name must be at least two characters and can only contain alphabeticals!")
        is_valid=False
    if not USER_REGEX.match(data['em']):
        flash("Email is invalid!")
        is_valid=False
    if len(email_list) != 0:
        flash("Email already in use!")
        is_valid=False
    
    if is_valid==False:
        return redirect('/')
    else:
        mysql = connectToMySQL('mydb')
        query="INSERT into users (first_name, last_name, emails, password, created_at) VALUES (%(fn)s, %(ln)s, %(em)s, %(pw)s, NOW());"
        session['id']=mysql.query_db(query, data)
        return redirect('/success')

@app.route('/login', methods=['POST'])
def login():
    is_valid=True
    mysql = connectToMySQL('mydb')
    query = ("SELECT * FROM users WHERE emails= %(em)s")
    data={
        'em':request.form['email'],
        'pw':request.form['password']
    }
    user=mysql.query_db(query, data)
    
    if len(user)!=1:
        is_valid=False

    elif not bcrypt.check_password_hash(user[0]['password'], data['pw']):
        is_valid=False
    
    if is_valid:
        session['id']=user[0]['id']
        return redirect('/success')
    else:
        flash("Invalid email/password")
        return redirect('/')

    
    



@app.route('/success')
def success():
    mysql = connectToMySQL('mydb')
    query="SELECT * FROM users WHERE id= %(user_id)s"
    if len(session) <1:
        return redirect('/')
    data={
        'user_id':session['id']
    }
    
    user=mysql.query_db(query, data)
    print(user[0])

    return render_template('success.html', user=user[0])

@app.route('/clear', methods=['POST'])
def clear():
    session.clear()
    return redirect('/')


if __name__ == "__main__":
    app.run(debug=True)


