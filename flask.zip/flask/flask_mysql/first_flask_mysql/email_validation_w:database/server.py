from flask import Flask, session, redirect, render_template, request, flash
from mysqlconnection import connectToMySQL
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

app=Flask(__name__)
app.secret_key='secret'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    mysql = connectToMySQL('mydb')
    query = ("INSERT INTO emails (content) VALUES (%(em)s);")
    data={
        'em':request.form['email']
    }
    if not EMAIL_REGEX.match(request.form['email']):
        flash("Email is not valid!")
        return redirect('/')
    else:
        email_id=mysql.query_db(query, data)
        flash(f"The email address you entered {request.form['email']} is a VALID email address. Thank you!")
        return redirect('/success')

@app.route('/success')
def success():
    mysql = connectToMySQL('mydb')
    query=("SELECT * FROM emails")
    emails = mysql.query_db(query)
    return render_template('index2.html', emails=emails)




if __name__=="__main__":
    app.run(debug=True)