from flask import Flask, session, redirect, render_template, request, flash
from mysqlconnection import connectToMySQL
app=Flask(__name__)
app.secret_key='secret'

@app.route('/')
def index():
    return render_template('index.html')
    


@app.route('/process', methods=['POST'])
def validation():
    is_valid = True
    if len(request.form['fname']) < 1:
    	is_valid = False
    	flash("Please enter a first name")
    if len(request.form['lname']) < 1:
    	is_valid = False
    	flash("Please enter a last name")
    
    if not is_valid:
        return redirect("/")
    else:
        mysql=connectToMySQL("mydb")
        query= "INSERT INTO programmers (first_name, last_name, location, language, comment, created_at) VALUES (%(fn)s, %(ln)s, %(loc)s, %(lan)s, %(com)s, NOW());"
        data ={
            'fn':request.form['fname'],
            'ln':request.form['lname'],
            'loc':request.form.get('location'),
            'lan':request.form.get('language'),
            'com':request.form['comment']
        }
        session['id']=mysql.query_db(query, data)
        flash("Programmer successfully added!")
        return redirect('/result')

@app.route('/result')
def result():
    mysql=connectToMySQL("mydb")
    data={
        'new_id': str(session['id'])
    }
    query= "SELECT * FROM programmers WHERE id = %(new_id)s;"
    dictionary=mysql.query_db(query, data)

    return render_template('index2.html', programmer=dictionary[0])

if __name__=="__main__":
    app.run(debug=True)