from flask import Flask, session, redirect, render_template, request
from mysqlconnection import connectToMySQL
app=Flask(__name__)
app.secret_key='secret'

@app.route('/')
def index():
    mysql = connectToMySQL("mydb")
    pets = mysql.query_db("SELECT * FROM pets;")
    return render_template('index.html', all_pets=pets)

@app.route('/process', methods=['POST'])
def process():
    mysql=connectToMySQL("mydb")
    query= "INSERT INTO pets (name, type, created_at, updated_at) VALUES (%(nm)s, %(tp)s, NOW(), NOW());"
    data ={
        'nm':request.form['name'],
        'tp':request.form['type']
    }
    new_pet_id = mysql.query_db(query, data)
    return redirect('/')




if __name__ == "__main__":
    app.run(debug=True)