SELECT * FROM mydb.friends;
DELETE FROM mydb.friends WHERE id=55;
UPDATE mydb.friends SET first_name="SEBASTIAN" WHERE id=2323;
