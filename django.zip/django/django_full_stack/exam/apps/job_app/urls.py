from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^dashboard$', views.success),
    url(r'^logout$', views.logout),
    url(r'^login$', views.login),
    url(r'^jobs/new$', views.new_job),
    url(r'^process$', views.process_job),
    url(r'^jobs/edit/(?P<job_id>\d+)$', views.edit_job),
    url(r'^update/(?P<job_id>\d+)$', views.update),
    url(r'^delete/(?P<job_id>\d+)$', views.delete),
    url(r'^view/(?P<job_id>\d+)$', views.view),
]
