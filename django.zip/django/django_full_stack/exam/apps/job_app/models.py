from __future__ import unicode_literals
from django.db import models
import re
import bcrypt



USER_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def validator(self, postData):
        errors= []
        #postData (dictionary) is going to hold the data of the potential user
        
        email_list= User.objects.filter(email=postData['email']) 

        if postData['password']!=postData['confirm']:
            errors.append("Passwords must match!")
        if len(postData['fname'])<2 or not postData['fname'].isalpha():
            errors.append("First name must be at least two characters and can only contain alphabeticals!")
        if len(postData['lname'])<2 or not postData['lname'].isalpha():
            errors.append("Last name must be at least two characters and can only contain alphabeticals!")
        if not USER_REGEX.match(postData['email']):
            errors.append("Email is invalid!")
        if len(email_list) != 0:
            errors.append("Email already in use!")
        return errors
    def register(self, postData):
        hashed_password=bcrypt.hashpw(postData['password'].encode(), bcrypt.gensalt())

        return self.create(
            first_name= postData['fname'],
            last_name= postData['lname'],
            email= postData['email'],
            hashed_password=hashed_password
        )

    def authenticate(self, email, password):
        users_with_email=self.filter(email=email)
        if len(users_with_email)!=1:
            return False
        else:
            return bcrypt.checkpw(password.encode(), users_with_email[0].hashed_password.encode())

class JobManager(models.Manager):
    def validator(self, postData):
        errors= []

        if len(postData['title'])<3:
            errors.append("Title must consist of at least three characters!")
        if len(postData['description'])<3:
            errors.append("Description must consist of at least three characters!")
        if len(postData['location'])<3:
            errors.append("Location must consist of at least three characters!")
        return errors

    def add_job(self, postData):
        return self.create(
            title= postData['title'],
            description= postData['description'],
            location=postData['location'],
        )
    def edit_job(self, postData, job_id):
        job_to_edit=Job.objects.get(id=job_id)
        job_to_edit.location=postData['location']
        job_to_edit.description=postData['description']
        job_to_edit.title=postData['title']
        job_to_edit.save()
        return 


class User(models.Model):
    first_name=models.CharField(max_length=45)
    last_name=models.CharField(max_length=45)
    email=models.CharField(max_length=45)
    hashed_password=models.CharField(max_length=255)
    objects=UserManager()

class Job(models.Model):
    title=models.CharField(max_length=45)
    description=models.TextField(null=True)
    creator=models.ForeignKey(User, related_name="created_jobs", null=True)
    location=models.CharField(max_length=45)
    employee=models.ForeignKey(User, related_name="jobs")
    posted_on = models.DateTimeField(auto_now_add=True)
    objects=JobManager()
