from django.apps import AppConfig


class TravelAppConfig(AppConfig):
    name = 'job_app'
