from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
import re
import bcrypt
from .models import User

def index(request):
    return render(request, 'login_app/index.html')

def register(request):
    errors=User.objects.validator(request.POST)
    #remember that request.post returns a dictionary with the form's input names as the keys!
    if len(errors)>0:
        for val in errors:
            messages.error(request, val)
        return redirect('/')
    else:
        new_user=User.objects.register(request.POST)
    request.session['id']=new_user.id
    return redirect('/success')

def success(request):
    if not 'id' in request.session:
        return redirect('/')
    else:
        current_user=User.objects.get(id=request.session['id'])
        context={
            "first_name":current_user.first_name
        }
        return render(request, 'login_app/success.html', context)

def logout(request):
    request.session.clear()
    return redirect('/')

def login(request):
    check_user= User.objects.authenticate(request.POST['email'], request.POST['password'])
    if check_user:
        current_user= User.objects.get(email=request.POST['email'])
        request.session['id']=current_user.id
        return redirect('/success')
    else:
        messages.error(request, 'Invalid Email/Password')
        return redirect('/')