from django.shortcuts import render, HttpResponse
from .models import Movie
# show all of the data from a table
def index(request):
    context = {
    	"all_the_movies": Movie.objects.all()
    }
    return render(request, "orm_app/index.html", context)
