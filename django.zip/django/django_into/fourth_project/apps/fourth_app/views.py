from django.shortcuts import render, HttpResponse, redirect
import random
def index(request):
    if not 'income' in request.session:
        request.session['income']=[]
    if not 'gold' in request.session:
        request.session['gold']=0
    if not 'activity' in request.session:
        request.session['activity']=[]
    if not 'turn' in request.session:
        request.session['turn']=0
    context={
       'activity':request.session['activity'],
       'turn':request.session['turn'],
       'income':request.session['income'],
    }
    return render(request, "fourth_app/index.html", context)
    
def process(request):
    if not 'income' in request.session:
        request.session['income']=[]
    if not 'gold' in request.session:
        request.session['gold']=0
    if not 'activity' in request.session:
        request.session['activity']=[]
    if not 'turn' in request.session:
        request.session['turn']=0
    location={
        "farm":(10,20),
        "cave":(5,10),
        "house":(2,5),
        "casino":(-50,50),
    }
    for key in location:
        if key in request.POST:
            history=request.session['income']
            history.append(random.randint(location[key][0], location[key][1]))
            request.session['gold']+=random.randint(location[key][0], location[key][1])
            request.session['activity'].append(f"Traveled to the {key}. Result: {random.randint(location[key][0], location[key][1])} gold.")
            request.session['turn']+=1            
    return redirect('/')

    