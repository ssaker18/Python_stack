from django.apps import AppConfig


class FourthAppConfig(AppConfig):
    name = 'fourth_app'
