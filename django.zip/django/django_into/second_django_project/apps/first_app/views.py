from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime
from datetime import datetime
    
def index(request):
    context = {
    	"time1": strftime('%b %d, %Y', gmtime()),
        "time2": strftime('%I:%M%p', gmtime()),

    }
    return render(request, "first_app/index.html", context)

def index2(request):
    return redirect("/")