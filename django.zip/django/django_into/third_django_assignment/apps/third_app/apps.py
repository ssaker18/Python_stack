from django.apps import AppConfig


class ThirdAppConfig(AppConfig):
    name = 'third_app'
