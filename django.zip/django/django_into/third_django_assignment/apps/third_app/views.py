from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string
    
def index(request):
    return render(request, "third_app/index.html")

def create(request):
    request.session['rw']= get_random_string(length=14)
    if not 'count' in request.session:
        request.session['count'] =0
    else:
        request.session['count'] += 1
    return redirect("/")

def reset(request):
    del request.session['count']
    del request.session['rw']
    return redirect('/random_word')
