import parent
print(locals())