#Biggie Size

def biggie_size(arr):
    for i in range(len(arr)):
        if arr[i]>0:
            arr[i]="big"
    return arr

print(biggie_size([-1, 3, 5, -5]))

#Count Positives 

def countPos(arr):
    count = 0
    for i in range(len(arr)):
        if arr[i]>0:
            count+=1
    arr[len(arr)-1]=count
    return arr

print(countPos([-1, 3, 5, -5]))


#Sum Total

def sum_total(arr):
    sum = 0
    for i in range(len(arr)):
        sum+=arr[i]
    return sum

print(sum_total([1,2,3,4]))

#Average

def average(arr):
    sum=0
    for i in range(len(arr)):
        sum+=arr[i]
    sum/=len(arr)
    return sum

print(average([1,2,3,4]))

#Length

def length(arr):
    i = 0
    for val in arr:
        i+=1
    return i

print(length([37,2,1,-9]))

#Minimum

def minimum(arr):
    if length(arr)==0:
        return False
    min = arr[0]
    for val in arr:
        if val<min:
            min=val
    return min

print(minimum([]))

#Maximum

def maximum(arr):
    if length(arr)==0:
        return False
    max = arr[0]
    for val in arr:
        if val>max:
            max=val
    return max

print(maximum([]))

#Ultimate Analysis

def ultimate_analysis(arr):
    ult={
        'sumTotal':sum_total(arr),
        'average':average(arr),
        'minimum':minimum(arr),
        'maximum':maximum(arr),
        'length':length(arr)
    }
    return ult

print(ultimate_analysis([37,2,1,-9]))

#Reverse

def reverse_list(arr):
    count=0
    i=0
    j=length(arr)-1
    while count<length(arr)/2:
        swap=arr[i]
        arr[i]=arr[j]
        arr[j]=swap
        j-=1
        i+=1
        count+=1

    return arr

print(reverse_list([37,2,1,-9]))
