#1 Countdown
def countDown(num):
    arr=[]
    for i in range(num,-1,-1):
        arr.append(i)
    return arr

print(countDown(4))

#2 Print and Return

def pAndr(arr):
    print(arr[0])
    return arr[1]

print(pAndr([1,2]))


#3 First Plus Length

def fPlusLen(arr):
    return arr[0]+len(arr)

print(fPlusLen([3,3,4]))


#4 Values Greater than Second

def valGreaterSecond(arr):
    count=0
    newarr=[]
    if len(arr)<2:
        return False
    for i in range(len(arr)):
        if arr[i]>arr[1]:
            newarr.append(arr[i])
            count+=1
    print(count)
    return newarr

print(valGreaterSecond([4,2,3]))

#This Length, That Value

def lenVal(size,value):
    arr=[]
    for i in range(size):
        arr.append(value)
    return arr

print(lenVal(4,7))
